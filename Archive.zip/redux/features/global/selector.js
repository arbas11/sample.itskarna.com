export const globalCounterValue = (state) => state.global.counter;
export const globalModalValue = (state) => state.global.modal;
