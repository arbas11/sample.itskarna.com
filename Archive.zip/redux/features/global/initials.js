export const initialState = {
  counter: 0,
  modal: null,
};
