import { RootState } from '@/redux/store';

export const modalValue = (state) => state.modal.modal;
