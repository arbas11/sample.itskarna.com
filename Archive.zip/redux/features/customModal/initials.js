import React from 'react';

const initialState = {
  modal: null,
};

export default initialState;
